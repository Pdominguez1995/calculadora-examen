package com.example.calculo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText ct1, ct2,ct3,ct4,ct5,ct6;
    Button btsumar;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ct1=(EditText) findViewById(R.id.ct1);
        ct2=(EditText) findViewById(R.id.ct2);
        ct3=(EditText) findViewById(R.id.ct3);
         ct4=(EditText) findViewById(R.id.ct4);
         ct5=(EditText) findViewById(R.id.ct5);
         ct6=(EditText) findViewById(R.id.ct6);
        btsumar =(Button) findViewById(R.id.btsumar);
        btsumar.setOnClickListener(this);



     }

    @Override
    public void onClick(View view) {
        float n1,n2,s,r,m,d;
        n1= Float.parseFloat(ct1.getText().toString());
        n2= Float.parseFloat(ct2.getText().toString());
        s=n1+n2;
        r=n1-n2;
        m=n1*n2;
        d=n1/n2;
        ct3.setText(""+s);
        ct4.setText(""+r);
        ct5.setText(""+m);
        ct6.setText(""+d);

    }
}
